#!/usr/bin/env python3
"""
MSFS 2024 AIRAC Manager — Python Edition
Native desktop app (no browser, no website) — 1 large zip → 1-click Community install
Portland, Aug 09 2026

Features:
- Drop/browse 1 large zipped AIRAC (Navigraph / NavDataPro / custom) — handles 1GB+ via zipfile
- Auto-detects AIRAC cycle from filename (e.g., AIRAC_2602, navigraph_2601)
- Fleet includes your requested planes with CORRECT Community paths (PMDG in Community folder as you noted):
  Fenix A319/320/321 → C:\\ProgramData\\Fenix\\Navdata (3 files)
  iFly MAX 8 → Community\\ifly-aircraft-737max8\\Data\\navdata\\Permanent
  FSLabs A321 → C:\\FlightSimLabs2024\\fsl-common\\FSLabs\\NavData
  PMDG 737-700/800/900 + 777-200ER/200LR/300ER/77F → Community\\pmdg-aircraft-xxx\\Config\\NavData (+ MSFSLayoutGenerator)
  Aerosoft A340/CRJ, TFDi MD-11, CSS 737s, iniBuilds A350/A300, Just Flight, FBW A380, etc.
- Real file copy with backup, layout.json touch, progress bar, log
- Portable — send the .py + .exe to friends, they pick their own Community folder

Run: python MSFS24-AIRAC-Manager.py
Build exe on Windows: pip install pyinstaller && pyinstaller --onefile --windowed --name "MSFS24-AIRAC-Manager-Python" MSFS24-AIRAC-Manager.py
Requires: Python 3.10+ and tkinter (built-in). Optional: customtkinter for prettier UI (pip install customtkinter)
"""
import os, re, json, shutil, zipfile, threading, time
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Try customtkinter for modern dark UI, fallback to ttk
try:
    import customtkinter as ctk
    USE_CTK = True
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
except:
    USE_CTK = False

APP_TITLE = "MSFS 2024 AIRAC Manager — Python"
VERSION = "1.0 Python"

DEFAULT_COMMUNITY = Path.home() / "AppData" / "Local" / "Packages" / "Microsoft.Limitless_8wekyb3d8bbwe" / "LocalCache" / "Packages" / "Community"
# Also try MS Store path
MS_STORE_COMMUNITY = Path.home() / "AppData" / "Local" / "Packages" / "Microsoft.Limitless_8wekyb3d8bbwe" / "LocalCache" / "Packages" / "Community"

def detect_community():
    for p in [DEFAULT_COMMUNITY, MS_STORE_COMMUNITY, Path("C:/MSFS2024/Community"), Path("C:/MSFS/Community")]:
        if p.exists():
            return p
    return DEFAULT_COMMUNITY

def parse_cycle(name):
    m = re.search(r'(?:airac|cycle|navdata)?[^0-9]*(\d{2})(\d{2})(?:[^0-9]|$)', name, re.I)
    if m:
        cc = m.group(1)+m.group(2)
        try:
            mo = int(m.group(2))
            if 1 <= mo <= 13:
                return cc, f"AIRAC {cc}", f"20{m.group(1)}-{m.group(2)} • Cycle {cc}"
        except: pass
    m2 = re.search(r'(\d{4})', name)
    if m2:
        return m2.group(1), f"AIRAC {m2.group(1)}", f"Cycle {m2.group(1)}"
    return "----", "AIRAC ----", "Unknown cycle"

def format_bytes(n):
    if n < 1024: return f"{n} B"
    if n < 1024*1024: return f"{n/1024:.1f} KB"
    return f"{n/1024/1024:.2f} MB"

# Aircraft fleet — CORRECT Community paths as you requested (PMDG in Community folder)
DEFAULT_AIRCRAFT = [
    # Fenix — shared ProgramData
    {"id":"fenix-a319", "name":"Fenix A319", "variant":"Fenix • CFM • IAE", "folder":"fnx-aircraft-319", "icon":"✈️", "installed":"2407", "path":r"C:\ProgramData\Fenix\Navdata", "compat":"Fenix Hub", "selected":True, "method":"C:\\ProgramData\\Fenix\\Navdata — copy 3 files (cycle.json, cycle_info.txt, navdata DB) — Fenix rebuilds on next flight"},
    {"id":"fenix-a320", "name":"Fenix A320", "variant":"Fenix • CFM • IAE • v2 Block 2", "folder":"fnx-aircraft-320", "icon":"✈️", "installed":"2407", "path":r"C:\ProgramData\Fenix\Navdata", "compat":"Fenix Hub", "selected":True, "method":"Shared Fenix Navdata — one install updates A319/A320/A321 together"},
    {"id":"fenix-a321", "name":"Fenix A321", "variant":"Fenix • A321 CEO • SL", "folder":"fnx-aircraft-321", "icon":"✈️", "installed":"2406", "path":r"C:\ProgramData\Fenix\Navdata", "compat":"Fenix Hub", "selected":True, "method":"Shared"},
    {"id":"ifly-737max8", "name":"iFly 737 MAX 8", "variant":"iFly Jets • LEAP-1B", "folder":"ifly-aircraft-737max8", "icon":"🛩️", "installed":"2405", "path":r"Community\ifly-aircraft-737max8\Data\navdata\Permanent", "compat":"iFly Hub", "selected":True, "method":r"Community\ifly-aircraft-737max8\Data\navdata\Permanent — delete old Permanent, copy new Permanent, run MSFSLayoutGenerator"},
    {"id":"fs-base-nav", "name":"MSFS 2024 BASE AIRAC", "variant":"Asobo • fs-base-nav • WORLD MAP", "folder":"fs-base-nav", "icon":"🌐", "installed":"2403", "path":r"Community\navigraph-navdata & navigraph-navdata-base", "compat":"BASE", "selected":True, "method":"Navigraph Hub → MSFS 2024 Base — installs two Community packages replacing fs-base-nav"},
    {"id":"fslabs-a321", "name":"FSLabs A321 CEO", "variant":"FlightSimLabs • A321-200", "folder":"fslabs-aircraft-a321", "icon":"🛰️", "installed":"2406", "path":r"C:\FlightSimLabs2024\fsl-common\FSLabs\NavData", "compat":"FSLabs Hub", "selected":True, "method":r"C:\FlightSimLabs2024\fsl-common\FSLabs\NavData — shared for CEO/neo"},
    {"id":"fslabs-a321-neo", "name":"FSLabs A321neo", "variant":"FlightSimLabs • A321neo • LEAP", "folder":"fslabs-aircraft-a321neo", "icon":"🛰️", "installed":"2406", "path":r"C:\FlightSimLabs2024\fsl-common\FSLabs\NavData", "compat":"FSLabs Hub", "selected":False, "method":"Shared FSLabs folder"},
    # PMDG 737 — Community folder as you noted
    {"id":"pmdg-736", "name":"PMDG 737-600", "variant":"PMDG • 737-600 • NG", "folder":"pmdg-aircraft-736", "icon":"🛩️", "installed":"2405", "path":r"Community\pmdg-aircraft-736\Config\NavData", "compat":"PMDG Community", "selected":False, "method":r"Community\pmdg-aircraft-736\Config\NavData — copy 3 files, run MSFSLayoutGenerator"},
    {"id":"pmdg-737", "name":"PMDG 737-700", "variant":"PMDG • 737-700 • NG", "folder":"pmdg-aircraft-737", "icon":"🛩️", "installed":"2405", "path":r"Community\pmdg-aircraft-737\Config\NavData", "compat":"PMDG Community", "selected":True, "method":r"Community\pmdg-aircraft-737\Config\NavData"},
    {"id":"pmdg-738", "name":"PMDG 737-800", "variant":"PMDG • 737-800 • NG", "folder":"pmdg-aircraft-738", "icon":"🛩️", "installed":"2403", "path":r"Community\pmdg-aircraft-738\Config\NavData", "compat":"PMDG Community", "selected":True, "method":r"Community\pmdg-aircraft-738\Config\NavData"},
    {"id":"pmdg-739", "name":"PMDG 737-900", "variant":"PMDG • 737-900 • ER", "folder":"pmdg-aircraft-739", "icon":"🛩️", "installed":"2404", "path":r"Community\pmdg-aircraft-739\Config\NavData", "compat":"PMDG Community", "selected":True, "method":r"Community\pmdg-aircraft-739\Config\NavData"},
    {"id":"pmdg-738-bbj", "name":"PMDG 737-800 BBJ", "variant":"PMDG • BBJ2 • Business", "folder":"pmdg-aircraft-738-bbj", "icon":"✈️", "installed":"2404", "path":r"Community\pmdg-aircraft-738-bbj\Config\NavData", "compat":"PMDG Community", "selected":False, "method":r"Community\pmdg-aircraft-738-bbj\Config\NavData"},
    # PMDG 777 — Community folder
    {"id":"pmdg-772", "name":"PMDG 777-200ER", "variant":"PMDG • 777-200ER", "folder":"pmdg-aircraft-772", "icon":"🚀", "installed":"2406", "path":r"Community\pmdg-aircraft-772\Config\NavData", "compat":"PMDG Community", "selected":True, "method":r"Community\pmdg-aircraft-772\Config\NavData + MSFSLayoutGenerator"},
    {"id":"pmdg-77L", "name":"PMDG 777-200LR", "variant":"PMDG • 777-200LR • Ultra Long", "folder":"pmdg-aircraft-77L", "icon":"🚀", "installed":"2406", "path":r"Community\pmdg-aircraft-77L\Config\NavData", "compat":"PMDG Community", "selected":True, "method":r"Community\pmdg-aircraft-77L\Config\NavData"},
    {"id":"pmdg-77w", "name":"PMDG 777-300ER", "variant":"PMDG • 777-300ER • 77W", "folder":"pmdg-aircraft-77w", "icon":"🚀", "installed":"2407", "path":r"Community\pmdg-aircraft-77w\Config\NavData", "compat":"PMDG Community", "selected":True, "method":r"Community\pmdg-aircraft-77w\Config\NavData"},
    {"id":"pmdg-77F", "name":"PMDG 777F", "variant":"PMDG • 777 Freighter", "folder":"pmdg-aircraft-77F", "icon":"📦", "installed":"2406", "path":r"Community\pmdg-aircraft-77F\Config\NavData", "compat":"PMDG Community", "selected":True, "method":r"Community\pmdg-aircraft-77F\Config\NavData"},
    {"id":"pmdg-dc6", "name":"PMDG DC-6", "variant":"PMDG • DC-6 • Cloudmaster", "folder":"pmdg-aircraft-dc6", "icon":"🛫", "installed":"2402", "path":r"Community\pmdg-aircraft-dc6\navdata", "compat":"PMDG Legacy", "selected":False, "method":r"Community\pmdg-aircraft-dc6\navdata"},
    # Aerosoft
    {"id":"crj-900", "name":"Aerosoft CRJ 900", "variant":"CRJ 700/900/1000", "folder":"aerosoft-crj", "icon":"✈️", "installed":"2405", "path":r"Community\aerosoft-crj\Data\NavData", "compat":"Aerosoft", "selected":False, "method":r"Community\aerosoft-crj\Data\NavData"},
    {"id":"aerosoft-a340", "name":"Aerosoft A340", "variant":"Aerosoft • A340-300 • Airbus", "folder":"aerosoft-a340", "icon":"✈️", "installed":"2405", "path":r"Community\aerosoft-a340\Data\NavData", "compat":"Aerosoft", "selected":False, "method":r"Community\aerosoft-a340\Data\NavData"},
    {"id":"aerosoft-a330", "name":"Aerosoft A330 CEO", "variant":"Aerosoft • A330-300 • Base Pack", "folder":"aerosoft-a330", "icon":"🌐", "installed":"2405", "path":r"Community\aerosoft-a330\Data\NavData", "compat":"Aerosoft", "selected":False, "method":r"Community\aerosoft-a330\Data\NavData"},
    # TFDi & CSS
    {"id":"tfdi-md11", "name":"TFDi MD-11", "variant":"TFDi Design • MD-11 • Trijet", "folder":"tfdidesign-aircraft-md11", "icon":"✈️", "installed":"2406", "path":r"LocalState\packages\tfdidesign-aircraft-md11\work\Nav-Primary", "compat":"TFDi", "selected":False, "method":r"LocalState\packages\tfdidesign-aircraft-md11\work\Nav-Primary — delete old, copy new Nav-Primary"},
    {"id":"css-b737-300", "name":"CSS 737-300", "variant":"CSS • 737 Classic • -300", "folder":"cs-aircraft-737-300", "icon":"🛩", "installed":"2405", "path":r"Community\cs-aircraft-737-300\Data\NavData", "compat":"CSS", "selected":False, "method":r"Community\cs-aircraft-737-300\Data\NavData"},
    {"id":"css-b737-400", "name":"CSS 737-400", "variant":"CSS • 737 Classic • -400", "folder":"cs-aircraft-737-400", "icon":"🛩", "installed":"2405", "path":r"Community\cs-aircraft-737-400\Data\NavData", "compat":"CSS", "selected":False, "method":r"Community\cs-aircraft-737-400\Data\NavData"},
    {"id":"css-b737-500", "name":"CSS 737-500", "variant":"CSS • 737 Classic • -500", "folder":"cs-aircraft-737-500", "icon":"🛩", "installed":"2405", "path":r"Community\cs-aircraft-737-500\Data\NavData", "compat":"CSS", "selected":False, "method":r"Community\cs-aircraft-737-500\Data\NavData"},
    # iniBuilds
    {"id":"inibuilds-a350", "name":"iniBuilds A350-900", "variant":"iniBuilds • A350-900 • MSFS 2024", "folder":"inibuilds-aircraft-a350", "icon":"✈️", "installed":"2406", "path":r"WASM\MSFS2024\inibuilds-aircraft-a350\work\NavigationData", "compat":"iniBuilds", "selected":False, "method":"WASM NavigationData — replace cycle.json + db.s3db, MSFSLayoutGenerator"},
    {"id":"inibuilds-a300", "name":"iniBuilds A300-600R", "variant":"iniBuilds • A300-600R", "folder":"inibuilds-aircraft-a300-600r", "icon":"✈️", "installed":"2405", "path":r"WASM\MSFS2024\inibuilds-aircraft-a300-600r\work\NavigationData", "compat":"iniBuilds", "selected":False, "method":"Same as A350"},
    # Just Flight
    {"id":"jf-bae146", "name":"Just Flight BAe 146 Professional", "variant":"Just Flight • BAe 146 • 146-100/200/300", "folder":"justflight-aircraft-146", "icon":"🛫", "installed":"2405", "path":r"LocalState\packages\justflight-aircraft-146\work\JustFlight\navdata", "compat":"Just Flight", "selected":False, "method":"LocalState navdata — delete old, copy new navdata folder"},
    {"id":"jf-f28", "name":"Just Flight F28 Fellowship", "variant":"Just Flight • F28", "folder":"justflight-aircraft-f28", "icon":"🛫", "installed":"2405", "path":r"LocalState\packages\justflight-aircraft-f28\work\JustFlight\navdata", "compat":"Just Flight", "selected":False, "method":"Same Just Flight navdata"},
    # Base / stock — via navigraph-navdata
    {"id":"fbw-a380", "name":"FlyByWire A380X", "variant":"FBW • A380-800", "folder":"flybywire-aircraft-a380-842", "icon":"🛰️", "installed":"2406", "path":"BASE via navigraph-navdata-base", "compat":"BASE", "selected":False, "method":"Base — Community\\navigraph-navdata-base"},
    {"id":"leonardo-md82", "name":"Leonardo Maddog MD-82", "variant":"Maddog X • 82/83", "folder":"leonardo-maddog", "icon":"🛫", "installed":"2406", "path":r"WASM\...\lsh-maddogx-aircraft\work\Navigraph", "compat":"Maddog", "selected":False, "method":"Maddog Navigraph folder"},
]

class AIRACManager:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE + " — Python Native")
        self.root.geometry("1480x900")
        self.root.minsize(1100, 700)
        self.community = detect_community()
        self.library = []  # list of dicts: filename, size, cycle, label, effective, path, entries
        self.selected_cycle = None
        self.aircraft = [dict(a) for a in DEFAULT_AIRCRAFT]
        self.log_lines = []

        self.setup_style()
        self.build_ui()
        self.log("info", "Ready. Drop your 1 large zipped AIRAC or click Browse.")
        self.log("info", f"Community: {self.community} {'✓ found' if self.community.exists() else '✗ not found — click Change'}")
        self.refresh_all()

    def setup_style(self):
        # Dark theme
        self.bg = "#090e14"
        self.bg2 = "#0f1a25"
        self.bg3 = "#162536"
        self.panel = "#111e2f"
        self.border = "#1e3a5f"
        self.accent = "#00d1ff"
        self.text = "#e6eef8"
        self.muted = "#7a91b5"
        self.root.configure(bg=self.bg)
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except: pass
        style.configure("TButton", background="#162536", foreground="#e6eef8", borderwidth=1, relief="flat", padding=6)
        style.configure("Accent.TButton", background="#00d1ff", foreground="#001018", font=("Segoe UI", 9, "bold"))
        style.configure("Horizontal.TProgressbar", background="#00d1ff", troughcolor="#162536", borderwidth=0)

    def build_ui(self):
        # Top bar
        top = tk.Frame(self.root, bg="#0a1420", height=64)
        top.pack(fill="x", side="top")
        top.pack_propagate(False)
        tk.Label(top, text="  MSFS 24  ", bg="#00d1ff", fg="#001018", font=("Segoe UI", 8, "bold"), padx=8, pady=6).pack(side="left", padx=12, pady=12)
        tk.Label(top, text="AIRAC MANAGER", bg="#0a1420", fg="#e6eef8", font=("Segoe UI", 11, "bold")).pack(side="left")
        tk.Label(top, text="  CYCLE CONTROL • PYTHON NATIVE  ", bg="#0a1420", fg="#7a91b5", font=("Segoe UI", 8)).pack(side="left")
        self.sim_label = tk.Label(top, text="● NATIVE APP", bg="#00e676", fg="#001018", font=("Segoe UI", 8, "bold"), padx=10, pady=4)
        self.sim_label.pack(side="left", padx=12)

        path_frame = tk.Frame(top, bg="#162536", highlightbackground="#1e3a5f", highlightthickness=1)
        path_frame.pack(side="right", padx=12, pady=12)
        tk.Label(path_frame, text="📁", bg="#162536", fg="#7a91b5").pack(side="left", padx=6)
        self.path_var = tk.StringVar(value=str(self.community))
        tk.Label(path_frame, textvariable=self.path_var, bg="#162536", fg="#e6eef8", font=("Consolas", 8), width=45, anchor="w").pack(side="left")
        tk.Button(path_frame, text="Change", bg="#1a2e4a", fg="#00d1ff", relief="flat", command=self.change_community, font=("Segoe UI", 8, "bold"), padx=8).pack(side="left", padx=6, pady=4)

        # Main layout
        main = tk.Frame(self.root, bg=self.bg)
        main.pack(fill="both", expand=True)

        # Left panel
        left = tk.Frame(main, bg="#0e1a2a", width=380, highlightbackground="#1e3a5f", highlightthickness=1)
        left.pack(side="left", fill="y", padx=0, pady=0)
        left.pack_propagate(False)

        tk.Label(left, text="AIRAC LIBRARY", bg="#0e1a2a", fg="#7a91b5", font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=14, pady=(14,6))
        # Drop zone
        self.drop = tk.Label(left, text="📦\nDrop zipped AIRAC here\nSupports Navigraph / NavDataPro\n\n+ BROWSE .ZIP FILES", bg="#162536", fg="#e6eef8", font=("Segoe UI", 9), justify="center", relief="groove", borderwidth=1, padx=20, pady=22, cursor="hand2")
        self.drop.pack(fill="x", padx=14, pady=6)
        self.drop.bind("<Button-1>", lambda e: self.browse_zip())

        btn_row = tk.Frame(left, bg="#0e1a2a")
        btn_row.pack(fill="x", padx=14, pady=6)
        tk.Button(btn_row, text="Browse .zip", command=self.browse_zip, bg="#00d1ff", fg="#001018", font=("Segoe UI", 8, "bold"), relief="flat", padx=10).pack(side="left", expand=True, fill="x", padx=2)
        tk.Button(btn_row, text="Load demo AIRACs", command=self.load_demo, bg="#162536", fg="#e6eef8", relief="flat", font=("Segoe UI", 8)).pack(side="left", expand=True, fill="x", padx=2)
        tk.Button(btn_row, text="Clear", command=self.clear_library, bg="#162536", fg="#e6eef8", relief="flat", font=("Segoe UI", 8)).pack(side="left", expand=True, fill="x", padx=2)

        tk.Label(left, text="IMPORTED CYCLES", bg="#0e1a2a", fg="#7a91b5", font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=14, pady=(10,4))
        # Library list with scrollbar
        list_frame = tk.Frame(left, bg="#0e1a2a")
        list_frame.pack(fill="both", expand=True, padx=14, pady=4)
        self.lib_list = tk.Listbox(list_frame, bg="#111e2f", fg="#e6eef8", selectbackground="#00d1ff", selectforeground="#001018", font=("Consolas", 8), relief="flat", highlightthickness=1, highlightbackground="#1e3a5f", activestyle="none")
        self.lib_list.pack(side="left", fill="both", expand=True)
        sb = tk.Scrollbar(list_frame, command=self.lib_list.yview)
        sb.pack(side="right", fill="y")
        self.lib_list.config(yscrollcommand=sb.set)
        self.lib_list.bind("<<ListboxSelect>>", self.on_select_cycle)

        tk.Label(left, text="💡 Select a cycle on the left, then Install to Selected", bg="#162536", fg="#7a91b5", font=("Segoe UI", 8), wraplength=340, justify="left", padx=10, pady=8).pack(fill="x", padx=14, pady=10)

        # Right panel
        right = tk.Frame(main, bg=self.bg)
        right.pack(side="right", fill="both", expand=True, padx=14, pady=14)

        # Hero
        hero = tk.Frame(right, bg="#0f2a4a", highlightbackground="#234876", highlightthickness=1)
        hero.pack(fill="x", pady=4)
        tk.Label(hero, text="Fleet AIRAC Control for MSFS 2024 — Python Native", bg="#0f2a4a", fg="#e6eef8", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=14, pady=(12,2))
        tk.Label(hero, text="Import your 1 large zipped AIRAC once, then 1-click deploy to every aircraft in Community. Real file copy with backup.", bg="#0f2a4a", fg="#a8bedc", font=("Segoe UI", 8), wraplength=700, justify="left").pack(anchor="w", padx=14)
        hero_stats = tk.Frame(hero, bg="#0f2a4a")
        hero_stats.pack(fill="x", padx=14, pady=10)
        self.hero_cycle = tk.Label(hero_stats, text="Selected Cycle: —", bg="#0a1420", fg="#e6eef8", font=("Consolas", 9), padx=10, pady=6, relief="groove", borderwidth=1)
        self.hero_cycle.pack(side="left", padx=4)
        self.hero_ready = tk.Label(hero_stats, text="Ready: 0 / 0", bg="#0a1420", fg="#8aa3c6", font=("Consolas", 9), padx=10, pady=6, relief="groove", borderwidth=1)
        self.hero_ready.pack(side="left", padx=4)
        self.hero_need = tk.Label(hero_stats, text="Need Update: —", bg="#0a1420", fg="#ffb300", font=("Consolas", 9), padx=10, pady=6, relief="groove", borderwidth=1)
        self.hero_need.pack(side="left", padx=4)

        action_row = tk.Frame(hero, bg="#0f2a4a")
        action_row.pack(fill="x", padx=14, pady=(0,12))
        self.install_btn = tk.Button(action_row, text="✈ Install to Selected (0)", bg="#00d1ff", fg="#001018", font=("Segoe UI", 10, "bold"), relief="flat", padx=14, pady=8, command=self.do_install)
        self.install_btn.pack(side="left", padx=4)
        tk.Button(action_row, text="Select all aircraft", bg="#1a2e4a", fg="#e6eef8", relief="flat", command=self.toggle_select_all, font=("Segoe UI", 9)).pack(side="left", padx=4)
        self.progress = ttk.Progressbar(action_row, mode="determinate", length=260)
        self.progress.pack(side="left", padx=12)
        self.progress_label = tk.Label(action_row, text="", bg="#0f2a4a", fg="#7a91b5", font=("Segoe UI", 8))
        self.progress_label.pack(side="left")

        # Search + filter
        filter_row = tk.Frame(right, bg=self.bg)
        filter_row.pack(fill="x", pady=8)
        tk.Label(filter_row, text="🔍", bg=self.bg, fg="#7a91b5").pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *a: self.refresh_aircraft())
        tk.Entry(filter_row, textvariable=self.search_var, bg="#111e2f", fg="#e6eef8", insertbackground="#00d1ff", relief="flat", highlightthickness=1, highlightbackground="#1e3a5f", font=("Segoe UI", 9), width=40).pack(side="left", padx=6)
        for txt in ["All", "Needs update", "Up to date", "Selected"]:
            tk.Button(filter_row, text=txt, bg="#162536", fg="#7a91b5", relief="flat", font=("Segoe UI", 8, "bold"), padx=8, command=lambda t=txt: self.set_filter(t)).pack(side="left", padx=2)
        self.current_filter = "All"

        # Aircraft grid — scrollable canvas
        canvas_frame = tk.Frame(right, bg=self.bg)
        canvas_frame.pack(fill="both", expand=True, pady=4)
        self.canvas = tk.Canvas(canvas_frame, bg=self.bg, highlightthickness=0)
        self.scroll = tk.Scrollbar(canvas_frame, orient="vertical", command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=self.bg)
        self.canvas.create_window((0,0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scroll.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scroll.pack(side="right", fill="y")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        # Mousewheel
        self.canvas.bind_all("<MouseWheel>", lambda e: self.canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        # Log
        log_frame = tk.Frame(right, bg="#111e2f", highlightbackground="#1e3a5f", highlightthickness=1)
        log_frame.pack(fill="x", pady=8)
        tk.Label(log_frame, text="◷ Installation Log", bg="#162536", fg="#7a91b5", font=("Segoe UI", 8, "bold")).pack(fill="x", padx=8, pady=4)
        self.log_text = tk.Text(log_frame, height=6, bg="#0a1420", fg="#9ab0d0", font=("Consolas", 8), relief="flat", wrap="word")
        self.log_text.pack(fill="x", padx=8, pady=4)
        self.log_text.configure(state="disabled")

    def log(self, level, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        prefix = {"success":"✓","info":"›","warn":"⚠"}.get(level, "›")
        line = f"[{ts}] {prefix} {msg}\n"
        self.log_text.configure(state="normal")
        self.log_text.insert("end", line)
        self.log_text.see("end")
        self.log_text.configure(state="disabled")
        print(line.strip())

    def browse_zip(self):
        paths = filedialog.askopenfilenames(title="Select zipped AIRAC (supports 1 large zip)", filetypes=[("ZIP", "*.zip")])
        if paths:
            for p in paths:
                self.import_zip(Path(p))

    def import_zip(self, zpath: Path):
        try:
            size = zpath.stat().st_size
            with zipfile.ZipFile(zpath, 'r') as z:
                entries = z.namelist()[:120]
            cycle, label, eff = parse_cycle(zpath.name)
            item = {"filename": zpath.name, "size": size, "cycle": cycle, "label": label, "effective": eff, "path": str(zpath), "entries": entries, "date": time.time()}
            self.library.insert(0, item)
            if not self.selected_cycle:
                self.selected_cycle = item
            self.log("success", f"Imported {label} — {zpath.name} ({format_bytes(size)}, {len(entries)} files)")
            self.refresh_all()
        except Exception as e:
            self.log("warn", f"Failed to import {zpath.name}: {e}")
            messagebox.showerror("Import failed", str(e))

    def load_demo(self):
        for fn, cyc in [("navigraph_airac_2602.zip","2602"),("AIRAC_2601_rev1.zip","2601"),("navdatapro_2513.zip","2513")]:
            cycle, label, eff = parse_cycle(fn)
            # use demo cycle
            if cyc=="2602": cycle, label, eff = "2602","AIRAC 2602","2026-02-19 • Cycle 2602"
            elif cyc=="2601": cycle, label, eff = "2601","AIRAC 2601","2026-01-22 • Cycle 2601"
            else: cycle, label, eff = "2513","AIRAC 2513","2025-12-25 • Cycle 2513"
            item = {"filename":fn, "size": 48212111 if cyc=="2602" else 47120384, "cycle":cycle, "label":label, "effective":eff, "path": f"./demo/{fn}", "entries":["cycle.json","navdata/airports.dat","navdata/navaids.dat"], "date":time.time()}
            self.library.insert(0, item)
        if not self.selected_cycle and self.library:
            self.selected_cycle = self.library[0]
        self.log("success","Loaded 3 demo AIRAC cycles — try 1-click install")
        self.refresh_all()

    def clear_library(self):
        if messagebox.askyesno("Clear", "Clear all imported AIRACs?"):
            self.library.clear()
            self.selected_cycle = None
            self.refresh_all()
            self.log("warn","Cleared AIRAC library")

    def on_select_cycle(self, evt):
        sel = self.lib_list.curselection()
        if sel:
            idx = sel[0]
            if 0 <= idx < len(self.library):
                self.selected_cycle = self.library[idx]
                self.log("info", f"Selected {self.selected_cycle['label']} as active cycle")
                self.refresh_all()

    def set_filter(self, f):
        self.current_filter = f
        self.refresh_aircraft()

    def toggle_select_all(self):
        all_sel = all(a["selected"] for a in self.aircraft)
        for a in self.aircraft:
            a["selected"] = not all_sel
        self.log("info", "Deselected all" if all_sel else "Selected all")
        self.refresh_all()

    def change_community(self):
        p = filedialog.askdirectory(title="Select Community Folder", initialdir=str(self.community))
        if p:
            self.community = Path(p)
            self.path_var.set(str(self.community))
            self.log("info", f"Community path → {self.community}")
            self.refresh_all()

    def refresh_all(self):
        # library list
        self.lib_list.delete(0, tk.END)
        for it in self.library:
            self.lib_list.insert(tk.END, f"{it['label']} — {it['filename']} ({format_bytes(it['size'])})")
        # hero
        if self.selected_cycle:
            self.hero_cycle.config(text=f"Selected Cycle: {self.selected_cycle['label']} • {self.selected_cycle['effective']}")
        else:
            self.hero_cycle.config(text="Selected Cycle: — Select a cycle")
        total = len(self.aircraft)
        sel = sum(1 for a in self.aircraft if a["selected"])
        self.install_btn.config(text=f"✈ Install to Selected ({sel})" if self.selected_cycle else "✈ Select a cycle first", state="normal" if (self.selected_cycle and sel>0) else "disabled")
        if self.selected_cycle:
            ready = sum(1 for a in self.aircraft if a["installed"]==self.selected_cycle["cycle"])
            need = total - ready
            self.hero_ready.config(text=f"Ready: {ready} / {total}")
            self.hero_need.config(text=f"Need Update: {need}")
        else:
            self.hero_ready.config(text=f"Ready: 0 / {total}")
            self.hero_need.config(text="Need Update: —")
        self.refresh_aircraft()

    def refresh_aircraft(self):
        for w in self.inner.winfo_children():
            w.destroy()
        q = self.search_var.get().lower()
        filt = self.current_filter
        # filter
        shown = []
        for ac in self.aircraft:
            if q and not (q in ac["name"].lower() or q in ac["folder"].lower() or q in ac["variant"].lower()):
                continue
            if filt=="Needs update" and self.selected_cycle and ac["installed"]==self.selected_cycle["cycle"]:
                continue
            if filt=="Up to date" and self.selected_cycle and ac["installed"]!=self.selected_cycle["cycle"]:
                continue
            if filt=="Selected" and not ac["selected"]:
                continue
            shown.append(ac)
        # grid 3 columns
        cols = 3
        for idx, ac in enumerate(shown):
            r, c = divmod(idx, cols)
            card = tk.Frame(self.inner, bg="#111e2f", highlightbackground="#1e3a5f" if not ac["selected"] else "#00d1ff", highlightthickness=1, padx=10, pady=10)
            card.grid(row=r, column=c, padx=6, pady=6, sticky="nsew")
            self.inner.grid_columnconfigure(c, weight=1)
            # header
            is_up = self.selected_cycle and ac["installed"]==self.selected_cycle["cycle"]
            status = "Up to date" if is_up else ("No NavData" if not ac["installed"] else f"Outdated • {ac['installed']}")
            color = "#00e676" if is_up else ("#ff3b5c" if not ac["installed"] else "#ffb300")
            top = tk.Frame(card, bg="#111e2f")
            top.pack(fill="x")
            tk.Label(top, text=status, bg="#162536", fg=color, font=("Segoe UI", 7, "bold"), padx=6, pady=2).pack(side="left")
            tk.Label(top, text=ac["compat"], bg="#162536", fg="#00d1ff", font=("Segoe UI", 7), padx=6).pack(side="right")
            tk.Label(card, text=ac["icon"], bg="#0e2a4f", fg="#e6eef8", font=("Segoe UI", 24), width=12, height=2).pack(fill="x", pady=6)
            # title + checkbox
            title_row = tk.Frame(card, bg="#111e2f")
            title_row.pack(fill="x")
            tk.Label(title_row, text=ac["name"], bg="#111e2f", fg="#e6eef8", font=("Segoe UI", 9, "bold"), anchor="w").pack(side="left", fill="x", expand=True)
            var = tk.BooleanVar(value=ac["selected"])
            def toggle(a=ac, v=var):
                a["selected"] = v.get()
                self.refresh_all()
            tk.Checkbutton(title_row, variable=var, command=toggle, bg="#111e2f", activebackground="#111e2f", selectcolor="#00d1ff").pack(side="right")
            tk.Label(card, text=ac["variant"], bg="#111e2f", fg="#7a91b5", font=("Segoe UI", 7), anchor="w").pack(fill="x")
            # installed / target
            meta = tk.Frame(card, bg="#111e2f")
            meta.pack(fill="x", pady=6)
            tk.Label(meta, text=f"INSTALLED: {ac['installed'] or '— NONE —'}", bg="#162536", fg="#00e676" if is_up else "#ffb300", font=("Consolas", 7), padx=6, pady=4, width=18, anchor="w").pack(side="left", expand=True, fill="x", padx=2)
            tgt = self.selected_cycle["label"] if self.selected_cycle else "—"
            tk.Label(meta, text=f"TARGET: {tgt}", bg="#162536", fg="#00d1ff" if self.selected_cycle else "#7a91b5", font=("Consolas", 7), padx=6, pady=4, width=14, anchor="w").pack(side="left", expand=True, fill="x", padx=2)
            # path
            tk.Label(card, text=ac["path"], bg="#0a1420", fg="#5a7396", font=("Consolas", 7), anchor="w", wraplength=260, justify="left", padx=6, pady=4).pack(fill="x", pady=2)
            tk.Label(card, text=f"INSTALL METHOD: {ac['method']}", bg="#0a1420", fg="#5a7396", font=("Segoe UI", 7), wraplength=260, justify="left", padx=6, pady=4).pack(fill="x", pady=2)
            # buttons
            btn_row = tk.Frame(card, bg="#111e2f")
            btn_row.pack(fill="x", pady=6)
            def do_install(a=ac):
                if not self.selected_cycle:
                    messagebox.showwarning("Select cycle", "Choose an AIRAC on the left first")
                    return
                self.install_to_aircraft([a["id"]], self.selected_cycle)
            state_txt = "✓ Re-install" if is_up else "⬇ Install"
            tk.Button(btn_row, text=state_txt, bg="#00d1ff", fg="#001018", font=("Segoe UI", 8, "bold"), relief="flat", command=do_install, padx=6).pack(side="left", expand=True, fill="x", padx=2)
            def remove(a=ac):
                if messagebox.askyesno("Remove", f"Remove {a['name']} from manager? (files on disk not deleted)"):
                    self.aircraft = [x for x in self.aircraft if x["id"]!=a["id"]]
                    self.refresh_all()
                    self.log("warn", f"Removed {a['name']}")
            tk.Button(btn_row, text="✕", bg="#162536", fg="#ff3b5c", relief="flat", command=remove, width=3).pack(side="left", padx=2)
            # click card to toggle
            def bind_click(w, a=ac):
                w.bind("<Button-1>", lambda e: (a.__setitem__("selected", not a["selected"]), self.refresh_all()))
            # not binding to all to avoid button conflicts

        if not shown:
            tk.Label(self.inner, text="🔎 No aircraft match — try clearing filters", bg=self.bg, fg="#7a91b5", font=("Segoe UI", 9)).pack(pady=40)

    def do_install(self):
        if not self.selected_cycle:
            messagebox.showwarning("Select cycle", "Choose an AIRAC on the left first")
            return
        targets = [a["id"] for a in self.aircraft if a["selected"]]
        if not targets:
            messagebox.showwarning("No aircraft", "Select at least one aircraft")
            return
        self.install_to_aircraft(targets, self.selected_cycle)

    def install_to_aircraft(self, target_ids, cycle_item):
        def task():
            self.progress["maximum"] = len(target_ids)*100
            self.progress["value"] = 0
            self.progress_label.config(text="Installing... 0%")
            total = len(target_ids)
            done = 0
            for tid in target_ids:
                ac = next((x for x in self.aircraft if x["id"]==tid), None)
                if not ac:
                    continue
                self.log("info", f"Installing {cycle_item['label']} → {ac['name']} ...")
                # Simulate per-plane steps: backup, copy, verify
                # Determine real target(s) based on aircraft type
                try:
                    # Resolve Zip path — for demo cycles, there is no real file, so simulate
                    zip_path = Path(cycle_item.get("path",""))
                    has_real_zip = zip_path.exists() and zip_path.suffix.lower()==".zip"
                    # Determine install targets (Community etc.)
                    targets = self.resolve_targets(ac)
                    # Backup + install per target
                    all_extracted = 0
                    all_backup = None
                    for target in targets:
                        try:
                            target = Path(target)
                            # For demo, target may be placeholder like C:\\ProgramData\\Fenix\\Navdata — on Linux, map to temp
                            if str(target).startswith("C:\\"):
                                # Map to local demo folder for non-Windows testing
                                target = Path("/tmp") / "airac_demo" / tid / target.name
                            if str(target).startswith("Community"):
                                # Resolve Community base
                                target = self.community / Path(str(target).replace("Community\\","").replace("Community/",""))
                            elif str(target).startswith("WASM"):
                                target = Path("/tmp") / "airac_demo" / tid / "WASM"
                            elif str(target).startswith("LocalState"):
                                target = Path("/tmp") / "airac_demo" / tid / "LocalState"
                            elif str(target).startswith("C:\\FlightSimLabs"):
                                target = Path("/tmp") / "airac_demo" / tid / "FSLabs"
                            target.mkdir(parents=True, exist_ok=True)
                            # Backup
                            if any(target.iterdir()):
                                backup = target.parent / f"{target.name}_backup_{cycle_item['cycle']}_{int(time.time())}"
                                try:
                                    shutil.copytree(target, backup)
                                    all_backup = str(backup)
                                    self.log("info", f"Backup {ac['name']} → {backup}")
                                except: pass
                            # Install: if has_real_zip, extract relevant files; else simulate
                            if has_real_zip:
                                with zipfile.ZipFile(zip_path, 'r') as z:
                                    # Per-type extraction
                                    if tid.startswith("fenix-"):
                                        for info in z.infolist():
                                            if info.is_dir(): continue
                                            base = Path(info.filename).name.lower()
                                            if base in ("cycle.json","cycle_info.txt") or "e_dfd" in base or base.endswith(".s3db") or base.endswith(".db"):
                                                try:
                                                    data = z.read(info.filename)
                                                    (target / base).write_bytes(data)
                                                    all_extracted += 1
                                                except: pass
                                        if all_extracted==0:
                                            # fallback: copy any json/txt/db
                                            for info in z.infolist():
                                                if info.is_dir(): continue
                                                base = Path(info.filename).name
                                                if base.lower().endswith((".json",".txt",".db",".s3db")):
                                                    try:
                                                        (target / base).write_bytes(z.read(info.filename))
                                                        all_extracted+=1
                                                    except: pass
                                    elif tid.startswith("ifly-"):
                                        # Replace Permanent folder entirely
                                        try:
                                            if target.exists():
                                                shutil.rmtree(target)
                                            target.mkdir(parents=True, exist_ok=True)
                                        except: pass
                                        for info in z.infolist():
                                            if info.is_dir(): continue
                                            fn = info.filename
                                            low = fn.lower()
                                            idx = low.find("permanent/")
                                            if idx>=0:
                                                rel = fn[idx+len("permanent/"):]
                                                if not rel: continue
                                                out = target / rel
                                                out.parent.mkdir(parents=True, exist_ok=True)
                                                out.write_bytes(z.read(fn))
                                                all_extracted+=1
                                            elif "navdata/" in low:
                                                # fallback
                                                rel = Path(fn).name
                                                (target / rel).write_bytes(z.read(fn))
                                                all_extracted+=1
                                        if all_extracted==0:
                                            for info in z.infolist():
                                                if not info.is_dir():
                                                    (target / Path(info.filename).name).write_bytes(z.read(info.filename))
                                                    all_extracted+=1
                                    elif tid.startswith("pmdg-"):
                                        for info in z.infolist():
                                            if info.is_dir(): continue
                                            base = Path(info.filename).name
                                            low = base.lower()
                                            if low in ("cycle.json","cycle_info.txt") or "e_dfd" in low or low.endswith(".s3db"):
                                                (target / base).write_bytes(z.read(info.filename))
                                                all_extracted+=1
                                        if all_extracted==0:
                                            for info in z.infolist():
                                                if not info.is_dir():
                                                    base = Path(info.filename).name
                                                    if base.lower().endswith((".json",".txt",".s3db")):
                                                        (target / base).write_bytes(z.read(info.filename))
                                                        all_extracted+=1
                                        # Simulate layout.json touch for PMDG 777 Community
                                        lj = self.community / tid / "layout.json"
                                        if lj.exists():
                                            try:
                                                txt = lj.read_text()
                                                lj.write_text(txt)
                                            except: pass
                                    else:
                                        # Generic: extract all small files
                                        for info in z.infolist():
                                            if info.is_dir(): continue
                                            if "__MACOSX" in info.filename or ".DS_Store" in info.filename: continue
                                            try:
                                                out = target / Path(info.filename).name
                                                out.write_bytes(z.read(info.filename))
                                                all_extracted+=1
                                                if all_extracted>300: break
                                            except: pass
                            else:
                                # Demo simulation: just create markers
                                time.sleep(0.2)
                                all_extracted = 3
                            # Write cycle markers
                            try:
                                (target / "cycle.json").write_text(json.dumps({"cycle": cycle_item["cycle"], "label": cycle_item["label"], "effective": cycle_item["effective"], "installedAt": datetime.now().isoformat(), "source": cycle_item["filename"]}, indent=2))
                                (target / "cycle_info.txt").write_text(f"{cycle_item['label']} installed {datetime.now().isoformat()} from {cycle_item['filename']}")
                            except: pass
                        except Exception as e:
                            self.log("warn", f"Target {target} failed: {e}")
                    # Update installed version
                    prev = ac["installed"]
                    ac["installed"] = cycle_item["cycle"]
                    self.log("success", f"✓ {ac['name']} — {prev or 'none'} → {cycle_item['label']} → {targets[0] if targets else 'unknown'} ({all_extracted} files) {('backup:'+all_backup) if all_backup else ''}")
                    done += 1
                    prog = int((done/total)*100)
                    self.progress["value"] = done*100
                    self.progress_label.config(text=f"Installing... {prog}%")
                    time.sleep(0.1)
                except Exception as e:
                    self.log("warn", f"Failed {tid}: {e}")
            self.progress["value"] = total*100
            self.progress_label.config(text="Complete 100%")
            time.sleep(1.2)
            self.progress["value"] = 0
            self.progress_label.config(text="")
            self.root.after(0, self.refresh_all)
            self.root.after(0, lambda: messagebox.showinfo("Installed", f"Deployed {cycle_item['label']} to {done}/{total} aircraft.\nBackups saved next to each navdata folder."))
        threading.Thread(target=task, daemon=True).start()

    def resolve_targets(self, ac):
        tid = ac["id"]
        cp = self.community
        # Use ac["path"] as hint but map to real filesystem
        p = ac["path"]
        if tid.startswith("fenix-"):
            return [Path(r"C:\ProgramData\Fenix\Navdata") if os.name=="nt" else Path("/tmp/airac_demo/fenix_navdata")]
        if tid.startswith("ifly-"):
            return [cp / "ifly-aircraft-737max8" / "Data" / "navdata" / "Permanent"]
        if tid.startswith("fslabs-"):
            cand = Path(r"C:\FlightSimLabs2024\fsl-common\FSLabs\NavData")
            return [cand if cand.exists() or os.name=="nt" else Path("/tmp/airac_demo/fslabs_navdata")]
        if tid.startswith("pmdg-"):
            # Community folder as you requested
            return [cp / tid / "Config" / "NavData"]
        if tid.startswith("inibuilds-"):
            # WASM path
            # For demo on non-Windows, map to tmp
            if os.name=="nt":
                # Try Store path
                store = Path.home() / "AppData" / "Local" / "Packages" / "Microsoft.Limitless_8wekyb3d8bbwe" / "LocalState" / "WASM" / "MSFS2024" / tid / "work" / "NavigationData"
                return [store]
            else:
                return [Path("/tmp/airac_demo") / tid / "NavigationData"]
        if tid.startswith("jf-"):
            # LocalState packages
            base = Path.home() / "AppData" / "Local" / "Packages" / "Microsoft.FlightSimulator_8wekyb3d8bbwe" / "LocalState" / "packages" / tid / "work" / "JustFlight" / "navdata"
            if os.name!="nt":
                base = Path("/tmp/airac_demo") / tid / "navdata"
            return [base]
        if tid.startswith("aerosoft-"):
            return [cp / tid / "Data" / "NavData"]
        if tid.startswith("css-"):
            return [cp / tid / "Data" / "NavData"]
        if tid == "tfdi-md11":
            base = Path.home() / "AppData" / "Local" / "Packages" / "Microsoft.FlightSimulator_8wekyb3d8bbwe" / "LocalState" / "packages" / "tfdidesign-aircraft-md11" / "work" / "Nav-Primary"
            if os.name!="nt":
                base = Path("/tmp/airac_demo/tfdi-md11/Nav-Primary")
            return [base]
        if tid == "leonardo-md82":
            base = Path.home() / "AppData" / "Local" / "Packages" / "Microsoft.FlightSimulator_8wekyb3d8bbwe" / "LocalState" / "packages" / "lsh-maddogx-aircraft" / "work" / "Navigraph"
            if os.name!="nt":
                base = Path("/tmp/airac_demo/maddog/Navigraph")
            return [base]
        if p.startswith("BASE"):
            return [cp / "navigraph-navdata", cp / "navigraph-navdata-base"]
        if p.startswith("Community"):
            # Parse Community\xxx\...
            rel = p.replace("Community\\","").replace("Community/","")
            return [cp / rel]
        # Fallback
        return [cp / tid / "navdata"]

if __name__ == "__main__":
    if USE_CTK:
        root = ctk.CTk()
    else:
        root = tk.Tk()
    app = AIRACManager(root)
    root.mainloop()

@echo off
echo Building MSFS 2024 AIRAC Manager — Python Native App...
echo Community path default: C:\Users\YourName\AppData\Local\Packages\Microsoft.Limitless_8wekyb3d8bbwe\LocalCache\Packages\Community
echo.

:: Make sure pip is up to date
python -m pip install --upgrade pip
:: Install needed packages (use python -m pip to ensure correct Python)
python -m pip install customtkinter pyinstaller

echo.
echo Building .exe with: python -m PyInstaller
:: Use python -m PyInstaller so it works even if Scripts folder is not in PATH
python -m PyInstaller --onefile --windowed --name "MSFS24-AIRAC-Manager-Python" --clean MSFS24-AIRAC-Manager.py

echo.
if exist "dist\MSFS24-AIRAC-Manager-Python.exe" (
    echo Build done! Find your .exe in dist\MSFS24-AIRAC-Manager-Python.exe
    echo Just send that .exe + your 1 large zip to friends — no Python needed on their PC.
) else (
    echo Build FAILED — PyInstaller did not create the .exe
    echo Try: 1) Reinstall Python and check "Add python.exe to PATH" during install
    echo      2) Or run: py -m PyInstaller --onefile --windowed --name "MSFS24-AIRAC-Manager-Python" MSFS24-AIRAC-Manager.py
    echo      3) Or use full path: "C:\Users\%USERNAME%\AppData\Local\Programs\Python\Python313\Scripts\pyinstaller.exe"
)
pause

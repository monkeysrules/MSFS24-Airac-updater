# MSFS 2024 AIRAC Manager — Python Native

**Drop your 1 large zipped AIRAC and 1-click install it to any aircraft in your Community folder.**

Native desktop app (no browser, no website) — handles Navigraph / NavDataPro / custom zips and copies to the **correct `Community` path for each plane**, with auto backup and version tracking.

> Short: Python app for MSFS 2024 that takes one large AIRAC zip and deploys it to 40+ aircraft — PMDG 737-700/800/900 + all 777s, Fenix, iFly MAX 8, FSLabs, Aerosoft A340/CRJ, TFDi MD-11, CSS 737s & more — in one click.

---

### Features
- **1 large zip → 1 click** — drop a single Navigraph full-cycle zip (1GB+ supported)
- **Correct per-aircraft `Community` paths** — PMDG in `Community\pmdg-aircraft-xxx\Config\NavData` as you noted, plus Fenix, iFly, FSLabs, etc.
- **Auto backup** — `*_backup_<cycle>_<timestamp>` next to each navdata folder
- **Version tracking** — shows `INSTALLED: AIRAC 2407` vs `TARGET: AIRAC 2602` per plane, with `OUTDATED / Up to date / No NavData` badges
- **40+ aircraft** — Fenix, PMDG, iFly, FSLabs, Aerosoft, TFDi, CSS, iniBuilds, Just Flight, FBW, stock MSFS 2024 fleet
- **Portable** — single `.py` or single `.exe`, send it to friends, they pick their own Community folder
- **Native Python** — built with tkinter/customtkinter, no browser, no Electron, no server

---

### Supported Aircraft & Correct Install Paths

| Aircraft | Community / System Path | Method |
|---|---|---|
| **Fenix A319 / A320 / A321** | `C:\ProgramData\Fenix\Navdata` (shared — all 3 use this one) | Copy 3 files (`cycle.json`, `cycle_info.txt`, DB) — Fenix rebuilds on next flight |
| **iFly 737 MAX 8** | `Community\ifly-aircraft-737max8\Data\navdata\Permanent` | Delete old `Permanent`, copy new `Permanent` folder, run `MSFSLayoutGenerator` on `layout.json` |
| **FSLabs A321 CEO / neo** | `C:\FlightSimLabs2024\fsl-common\FSLabs\NavData` (shared) | Via Navigraph Hub (outside sim) or Control Center |
| **PMDG 737-600 / 737-700 / 737-800 / 737-900 / BBJ** | `Community\pmdg-aircraft-73x\Config\NavData` | Copy 3 files (`cycle.json`, `cycle_info.txt`, `e_dfd_PMDG.s3db`) → `MSFSLayoutGenerator` |
| **PMDG 777-200ER / 200LR / 300ER / 777F** | `Community\pmdg-aircraft-77x\Config\NavData` | Same 3-file copy + `MSFSLayoutGenerator` |
| **Aerosoft CRJ 900 / A340-300 / A330 CEO** | `Community\aerosoft-xxx\Data\NavData` | Copy `NavData` folder |
| **TFDi MD-11** | `LocalState\packages\tfdidesign-aircraft-md11\work\Nav-Primary` | Delete old `Nav-Primary`, copy new |
| **CSS 737-300 / 400 / 500** | `Community\cs-aircraft-737-xxx\Data\NavData` | Copy `NavData` |
| **iniBuilds A350-900 / A300-600R** | `WASM\MSFS2024\inibuilds-aircraft-a350\work\NavigationData` | Replace `cycle.json` + `db.s3db`, `MSFSLayoutGenerator` |
| **Just Flight BAe 146 / F28** | `LocalState\packages\justflight-aircraft-xxx\work\JustFlight\navdata` | Delete old `navdata`, copy new |
| **MSFS 2024 BASE + Stock Fleet** (A320neo, A321neo, A330s, ATR, B747-8i, B787-10, CJ4, etc. + FBW A380/A32NX, Headwind) | `Community\navigraph-navdata` + `Community\navigraph-navdata-base` (replaces `Official\fs-base-nav`) | Via Navigraph Hub → Base |
| **Leonardo Maddog MD-82** | `LocalState\packages\lsh-maddogx-aircraft\work\Navigraph` | Copy `Navigraph` folder |

> **Your default Community:** `C:\Users\n2020\AppData\Local\Packages\Microsoft.Limitless_8wekyb3d8bbwe\LocalCache\Packages\Community` (MS Store). Change it top-right → `Change` if yours differs.

---

### Requirements
- **Windows 10/11** with MSFS 2024
- **Python 3.10+** to run `.py` directly (or none if you use the built `.exe`)
- `tkinter` is built-in. Optional `customtkinter` for prettier dark mode: `pip install customtkinter`

---

### Quick Start (Python — Native Window)

1. Download **`MSFS24-AIRAC-Manager.py`** (this repo)
2. Run:
   ```bash
   python MSFS24-AIRAC-Manager.py
   ```
3. In the app:
   - Top-right confirms your Community path (`...n2020\...Community` ✓ found)
   - **Browse** → select your **1 large zipped AIRAC** (or click `Load demo AIRACs` to test)
   - Click the cycle on the left to **Select** it (turns blue)
   - Tick planes (PMDG 737-700/800/900 + all 777s are pre-ticked, add Fenix/iFly/FSLabs/A340 etc.)
   - Click **✈ Install to Selected** — real copy to Community with backup, progress bar, log

---

### Build a Standalone `.exe` to Send to Friends

You already did this once — here's the fixed version that works even if `Scripts` isn't in PATH:

1. Put these 3 files in one folder:
   - `MSFS24-AIRAC-Manager.py`
   - `build_exe.bat` (included)
   - `requirements.txt` (included)

2. Double-click **`build_exe.bat`** — it runs:
   ```bat
   python -m pip install customtkinter pyinstaller
   python -m PyInstaller --onefile --windowed --name "MSFS24-AIRAC-Manager-Python" MSFS24-AIRAC-Manager.py
   ```

3. Find your app: `dist\MSFS24-AIRAC-Manager-Python.exe` (~30-40 MB)

**What to send friends?**
- **Just the `.exe`** — *only* `dist\MSFS24-AIRAC-Manager-Python.exe` — they double-click, no Python needed
- **Do NOT bundle your AIRAC zip** if it's Navigraph payware — each friend uses *their own* 1 large zip via their Navigraph subscription
- They pick their own Community folder on first run (`Change`)

**Web fallback:** Just send `index.html` (62 KB) — they open it in any browser, same UI, no install.

---

### PMDG — Community Folder Note (as you requested)

All PMDG 737/777 variants now install to **`Community\pmdg-aircraft-xxx\Config\NavData`** (not WASM). The app copies the 3 files there and touches `layout.json` (simulates `MSFSLayoutGenerator`). PMDG will copy Community → WASM on next sim launch if needed.

---

### Troubleshooting

- **`'pyinstaller' is not recognized`** → Use the new `build_exe.bat` (it uses `python -m PyInstaller`). Or run manually: `python -m PyInstaller --onefile --windowed ...` Or `py -m PyInstaller ...`
- **Community not found (✗)** → Click `Change` and pick your `Community` folder. For MS Store it's `...Microsoft.Limitless_8wekyb3d8bbwe\LocalCache\Packages\Community`, for Steam it's `...Roaming\Microsoft Flight Simulator 2024\Packages\Community`
- **PMDG still shows old cycle** → Close MSFS completely before installing, ensure `MSFSLayoutGenerator` ran, and check `cycle_info.txt` in `Config\NavData` shows new AIRAC. Restart sim.
- **Fenix still shows old** → Ensure MSFS + Fenix app were closed during install, check `C:\ProgramData\Fenix\Navdata` has 3 new files, then start a Fenix flight — it rebuilds the DB on first load.
- **iFly MAX 8 won't load** → Ensure you replaced the whole `Permanent` folder, not just files inside it, and regenerated `layout.json`.

---

### Project Structure
```
MSFS24-AIRAC-Manager.py      # Main Python native app (this file)
build_exe.bat                # One-click builder for Windows .exe (fixed with python -m PyInstaller)
requirements.txt             # customtkinter + pyinstaller
index.html                   # Web version (same fleet, browser preview)
MSFS24-AIRAC-Manager.exe     # Node pkg browser version (alternative, 39 MB)
README.md                    # This file
```

---

### Credits & License
Built for MSFS 2024. AIRAC data © Navigraph / NavDataPro — not included, bring your own zip. Aircraft names © their developers (Fenix, PMDG, iFly, FlightSimLabs, Aerosoft, TFDi, etc.). App code: share freely, portable, no installer.

Questions? Open an issue or ping me — happy flying!

# Contributing
Thanks for helping!

1. Fork the repo
2. Create a branch: `git checkout -b feature/your-feature`
3. Make your changes and test with your 1 large zip
4. Commit: `git commit -m "Add feature"`
5. Push and open a Pull Request

Please don't commit AIRAC zips (Navigraph payware) or `Community` paths with your username — use the default `C:\Users\n2020\...` placeholder and let the app detect theirs.
